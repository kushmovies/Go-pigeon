# Go Pigeon V1

Mobile-first Android project.

## Main modes
1. Chat to Pigeon — user talks directly with the AI/Pigeon.
2. Chat by Pigeon — user communicates with another person through the Pigeon/AI layer.

This V1 is the clean starting project. Backend/auth/messaging can be added in later steps without mixing old project files.
