package com.gopigeon.app

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "🕊️ Go Pigeon"
            textSize = 30f
            setPadding(0, 0, 0, 24)
        }
        val subtitle = TextView(this).apply {
            text = "Get connected"
            textSize = 18f
            setPadding(0, 0, 0, 32)
        }

        val chatTo = Button(this).apply {
            text = "Chat to Pigeon"
            setOnClickListener { subtitle.text = "Chat to Pigeon — बात करें AI कबूतर से" }
        }
        val chatBy = Button(this).apply {
            text = "Chat by Pigeon"
            setOnClickListener { subtitle.text = "Chat by Pigeon — कबूतर के माध्यम से दूसरे व्यक्ति से बात करें" }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(chatTo)
        root.addView(chatBy)
        setContentView(root)
    }
}
